<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    include("conexion.php");

    class Usuario extends Conexion
    {
        public function consultarUsuario($cedula, $password)
        {
            $query="SELECT * FROM `usuarios` WHERE cedula = '".$cedula."' AND password='".$password."'";
            $con = $this->conectarDB()->prepare($query);
            $con->execute();
            $fetch = $con->fetch(PDO::FETCH_ASSOC);
            echo json_encode($fetch);
            //echo $con->rowCount();
            
            /*$consulta = $con->query($query);
            $persona= $consulta->fetch();
            echo $persona->rowCount();
            echo json_encode($persona);*/
        }
    }
?>