<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    include("conexion.php");

    class Consecutivo extends Conexion
    {
        public function consultarConsecutivos($cedula,$codigo_dependencia)
        {
            //$query="SELECT * FROM `consecutivos` WHERE cedula = '".$cedula."' AND codigo_dependencia='".$codigo_dependencia."'";
            $query="SELECT ".
            "consecutivos.indice, ".
            "consecutivos.codigo_dependencia, ".
            "consecutivos.codigo_serie, ".
            "consecutivos.codigo_tdocumental, ".
            "consecutivos.consecutivo, ".
            "consecutivos.asunto, ".
            "consecutivos.destinatario, ".
            "consecutivos.fechaRegistro, ".
            "usuarios.cedula, ".
            "usuarios.nombre_completo as nombreUsuario, ".
            "dependencia.nombre as nombreDependencia ".
            "FROM `consecutivos`".
            " LEFT JOIN `usuarios` ON(usuarios.cedula = consecutivos.cedula)".
            " LEFT JOIN `dependencia` ON(dependencia.codigo_dependencia = usuarios.codigo_dependencia)".
            " WHERE consecutivos.cedula = '".$cedula."' AND consecutivos.codigo_dependencia = '".$codigo_dependencia."' order by consecutivos.indice DESC ";
            $con = $this->conectarDB()->prepare($query);
            $con->execute();
            $fetch = $con->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($fetch);
        }
        public function consultarTodoConsecutivos($codigo_dependencia)
        {
            $query="SELECT ".
            "consecutivos.indice, ".
            "consecutivos.codigo_dependencia, ".
            "consecutivos.codigo_serie, ".
            "consecutivos.codigo_tdocumental, ".
            "consecutivos.consecutivo, ".
            "consecutivos.asunto, ".
            "consecutivos.destinatario, ".
            "consecutivos.fechaRegistro, ".
            "usuarios.cedula, ".
            "usuarios.nombre_completo as nombreUsuario, ".
            "dependencia.nombre as nombreDependencia ".
            "FROM `consecutivos`".
            " LEFT JOIN `usuarios` ON(usuarios.cedula = consecutivos.cedula)".
            " LEFT JOIN `dependencia` ON(dependencia.codigo_dependencia = usuarios.codigo_dependencia)".
            " WHERE consecutivos.codigo_dependencia = '".$codigo_dependencia."'  order by consecutivos.indice DESC";
            $con = $this->conectarDB()->prepare($query);
            $con->execute();
            $fetch = $con->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($fetch);
        }
        
        public function addConsecutivos($codigo_dependencia,$codigo_serie,$codigo_tdocumental,$cedula,$asunto,$fechaRegistro,$destinatario)
        {
            $query = "INSERT INTO `consecutivos`(`codigo_dependencia`, `codigo_serie`, `codigo_tdocumental`, `consecutivo`, `cedula`, `asunto`, `fechaRegistro`, `destinatario`)".
            "SELECT".
            "'".$codigo_dependencia."' as codigo_dependencia,".
            "'".$codigo_serie."' as codigo_serie,".
            "'".$codigo_tdocumental."' as codigo_tdocumental,".
            "(IFNULL(MAX(`consecutivo`)+1,1)) as consecutivo ,".
            "'".$cedula."' as cedula,".
            "'".$asunto."' as asunto,".
            "'".$fechaRegistro."' as fechaRegistro,".
            "'".$destinatario."' as destinatario ".
            "FROM `consecutivos` WHERE `codigo_dependencia`='".$codigo_dependencia."' and `codigo_serie`='".$codigo_serie."' and `codigo_tdocumental`='".$codigo_tdocumental."'";
            $con = $this->conectarDB()->prepare($query);
            $con->execute();
            $fetch = $con->fetch(PDO::FETCH_ASSOC);
            //echo($query);
            echo json_encode($fetch);
        }
    }
?>