<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
include('consecutivo.php');

$post =file_get_contents("php://input");
$data = json_decode($post,true);

$consulta = new Consecutivo();
$consulta->addConsecutivos($data['codigo_dependencia'],$data['codigo_serie'],$data['codigo_tdocumental'],$data['cedula'],$data['asunto'],$data['fechaRegistro'],$data['destinatario']);

?>