<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
include('series.php');

//$post =file_get_contents("php://input");
//$data = json_decode($post,true);

$consulta = new Series();
$consulta->consultarSeries();


?>