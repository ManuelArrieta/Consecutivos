<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
include('consecutivo.php');

$post =file_get_contents("php://input");
$data = json_decode($post,true);

$consulta = new Consecutivo();
$operacion = $data['op'];

switch($operacion)
{
    case '0':
        $consulta->consultarConsecutivos($data['cedula'],$data['codigo_dependencia']);
        break;
    case '1':
        $consulta->consultarTodoConsecutivos($data['codigo_dependencia']);
    default:
        break;
}

?>