<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    include("conexion.php");

    class Series extends Conexion
    {
        public function consultarSeries()
        {
            $query="SELECT * FROM `series`";
            $con = $this->conectarDB()->prepare($query);
            $con->execute();
            $fetch = $con->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($fetch);
        }
    }
?>