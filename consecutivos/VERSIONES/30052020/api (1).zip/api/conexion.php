<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    abstract class Conexion
    {
        protected function conectarDB()
        {
            try
            {
                $con = new PDO("mysql:host=localhost;dbname=hackersj_consecutivos","hackersj_consec","ojesam92");
                return $con;
            }
            catch(PDOException $Erro)
            {
                echo $Erro->getMessage();
            }
        }
    }
?>