<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
include('usuario.php');

$post =file_get_contents("php://input");
$data = json_decode($post,true);

$usuario = new Usuario();
$usuario->consultarUsuario($data['cedula'],$data['password']);
?>